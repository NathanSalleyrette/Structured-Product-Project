#ifndef _PNL_NAMES_
#define _PNL_NAMES_

#define lgam pnl_sf_log_gamma
#define erf pnl_sf_erf
#define erfc pnl_sf_erfc
#define igam pnl_sf_gamma_inc_P
#define igamc pnl_sf_gamma_inc_Q
#define expn pnl_sf_expint_En
#define hyp2f1 pnl_sf_hyperg_2F1
#define hyperg pnl_sf_hyperg_1F1
#define round pnl_round


#endif /* _PNL_NAMES_ */
