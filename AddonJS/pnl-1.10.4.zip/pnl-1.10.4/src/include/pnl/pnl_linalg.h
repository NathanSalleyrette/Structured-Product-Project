#ifndef _PNL_LINALG_H
#define _PNL_LINALG_H

#include "pnl/pnl_vector.h"
#include "pnl/pnl_matrix.h"
#include "pnl/pnl_tridiag_matrix.h"
#include "pnl/pnl_band_matrix.h"

#endif /* _PNL_LINALG_H */
