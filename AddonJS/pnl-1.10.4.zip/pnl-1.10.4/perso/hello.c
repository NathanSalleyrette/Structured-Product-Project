#include <stdio.h>

void my_hello_world ()
{
  printf("Hello World \n");
}
